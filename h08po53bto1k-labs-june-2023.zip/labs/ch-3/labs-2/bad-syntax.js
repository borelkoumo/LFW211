'use strict'

function f (a, a) {
  
}